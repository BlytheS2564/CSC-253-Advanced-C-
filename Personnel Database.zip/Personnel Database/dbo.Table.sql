﻿CREATE TABLE [dbo].[Table]
(
	[Employee ID] INT NOT NULL PRIMARY KEY, 
    [Name] NVARCHAR(50) NOT NULL, 
    [Position] NVARCHAR(50) NOT NULL, 
    [Hourly Pay Rate] MONEY NOT NULL
)
