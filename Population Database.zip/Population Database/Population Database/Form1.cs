﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 12-10-19
* CSC 253
* Samuel Blythe
* Population Database - Sorts a population database
*/

namespace Population_Database
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.OrderPopASC(this.populationDBDataSet.City);
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.OrderPopDesc(this.populationDBDataSet.City);
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.OrderCityASC(this.populationDBDataSet.City);
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.PopSUM(this.populationDBDataSet.City);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.PopAVG(this.populationDBDataSet.City);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.PopMax(this.populationDBDataSet.City);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.PopMin(this.populationDBDataSet.City);
        }
    }
}
