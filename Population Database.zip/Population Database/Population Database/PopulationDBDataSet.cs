﻿namespace Population_Database
{


    partial class PopulationDBDataSet
    {
    }
}

namespace Population_Database.PopulationDBDataSetTableAdapters {
    
    
    public partial class CityTableAdapter {
    }
}
