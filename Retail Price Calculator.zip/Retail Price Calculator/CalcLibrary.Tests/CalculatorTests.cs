﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalcLibrary;
using Xunit;

namespace CalcLibrary.Tests
{
    public class CalculatorTests
    {
        [Fact]
        public void CalculatePercentage_SimpleValuesShouldMultiply()
        {
            // Arrange
            double expected = 25;

            // Act
            double actual = Retail_Price_Calculator.Program.CalculatePercentage(100, .25);

            // Assert
            Assert.Equal(expected, actual);
        }



        [Theory]
        [InlineData(100, 25, 125)]
        public void CalculateRetail_SimpleValuesShouldAdd(double x, double y, double expected)
        {
            // Arrange

            // Act
            double actual = Retail_Price_Calculator.Program.CalculateRetail(x, y);

            // Assert
            Assert.Equal(expected, actual);

        }
    }


}
