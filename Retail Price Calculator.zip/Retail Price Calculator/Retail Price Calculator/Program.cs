﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 11-12-19
* CSC 253
* Samuel Blythe
* Performs Tests to check the math in the retail markup program.
*/

namespace Retail_Price_Calculator
{
    public class Program
    {
        public static void Main(string[] args)
        {
            bool exit = false;
            double wholeSale = 0;
            double markUp = 0;
            double retailPrice = 0;
            

            do
            {
                MainMenu();
                string input = Console.ReadLine();
                if (input == "1")
                {
                    wholesale();
                    string input2 = Console.ReadLine();
                    if (double.TryParse(input2, out wholeSale))
                    {
                        markup();
                        string input3 = Console.ReadLine();
                        if (double.TryParse(input3, out markUp))
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine($"Item Wholesale Price: ${wholeSale}");
                            Console.WriteLine($"Item MarkUp Percentage (as decimal): {markUp}%");
                            double percentage = CalculatePercentage(wholeSale, markUp);
                            retailPrice = CalculateRetail(wholeSale, percentage);
                            DisplayRetail(retailPrice);
                        }
                        else
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("Please Enter a Valid Number.");
                        }
                    }
                    else
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("Please Enter a Valid Number.");
                    }
                }
                else if (input == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine(" ");
                    Console.WriteLine(" ");
                    Console.WriteLine("Please Type 1 or 2.");
                    Console.WriteLine(" ");
                }

            } while (exit == false);

        }

        public static void MainMenu()
        {
            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine("Would you like to run the program?");
            Console.WriteLine("1. Run");
            Console.WriteLine("2. Exit ");
            Console.WriteLine(" ");
        }

        public static void wholesale()
        {
            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine("Enter Item Wholesale Cost:");
            Console.WriteLine(" ");
        }
        public static void markup()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Enter Item Markup percentage:");

        }

        public static double CalculatePercentage(double wholeSale, double markUp)
        {
            double percentage = wholeSale * markUp;
            return percentage;
        }

        public static double CalculateRetail (double wholeSale, double percentage)
        {      
            double retailPrice = percentage + wholeSale;
            return retailPrice;
        }

        public static void DisplayRetail(double retailPrice)
        {
            Console.WriteLine($"Item Retail Price: ${retailPrice}");
        }

    }
}
