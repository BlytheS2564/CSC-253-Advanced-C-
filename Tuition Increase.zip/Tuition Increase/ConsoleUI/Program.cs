﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

/**
* 11-16-19
* CSC 253
* Samuel Blythe
* Tests the math in the Tuition Increase program
*/

namespace ConsoleUI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            double tuition = 12000;
            double increase = 0.02;

            Console.WriteLine($"Year 1 tuition: {tuition.ToString("C", CultureInfo.CurrentCulture)}");
            for (int count = 1; count <= 5; count++)
            {
                if (count > 1)
                {
                    tuition = CalculateTuition(tuition, increase);
                    Console.WriteLine("");
                    Console.WriteLine($"Year {count} tuition: {tuition.ToString("C", CultureInfo.CurrentCulture)}");
                }
            }
            Console.ReadLine();

        }
        public static double CalculateTuition(double tuition, double increase)
        {
            tuition += tuition * increase;
            return tuition;
        }
    }
}
