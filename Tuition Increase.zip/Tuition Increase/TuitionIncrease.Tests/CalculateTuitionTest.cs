﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace TuitionIncrease.Tests
{
    public class CalculateTuitionTest
    {
        [Theory]
        [InlineData(100, .03, 103)]
        public void CalculateTuition_SimpleValuesShouldCalculate(double x, double y, double expected)
        {
            // Arrange

            // Act
            double actual = ConsoleUI.Program.CalculateTuition(x, y);

            // Assert
            Assert.Equal(expected, actual);
        }
    }
}
